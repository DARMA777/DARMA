/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

/**
 *
 * @author cepardov
 */
public class Persona {
    protected int idPersona;
    protected String rutPersona;
    protected String nombrePersona;
    protected String paternoPersona;
    protected String maternoPersona;
    protected String nacimientoPersona;
    protected int idUsuario;
    protected int idTelefono;
    protected int idCorreo;

    public int getIdPersona() {
        return idPersona;
    }

    public String getRutPersona() {
        return rutPersona;
    }

    public void setRutPersona(String rutPersona) {
        this.rutPersona = rutPersona;
    }
    

    public void setIdPersona(int idPersona) {
        this.idPersona = idPersona;
    }

    public String getNombrePersona() {
        return nombrePersona;
    }

    public void setNombrePersona(String nombrePersona) {
        this.nombrePersona = nombrePersona;
    }

    public String getPaternoPersona() {
        return paternoPersona;
    }

    public void setPaternoPersona(String paternoPersona) {
        this.paternoPersona = paternoPersona;
    }

    public String getMaternoPersona() {
        return maternoPersona;
    }

    public void setMaternoPersona(String maternoPersona) {
        this.maternoPersona = maternoPersona;
    }

    public String getNacimientoPersona() {
        return nacimientoPersona;
    }

    public void setNacimientoPersona(String nacimientoPersona) {
        this.nacimientoPersona = nacimientoPersona;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdCorreo() {
        return idCorreo;
    }

    public void setIdCorreo(int idCorreo) {
        this.idCorreo = idCorreo;
    }

    public int getIdTelefono() {
        return idTelefono;
    }

    public void setIdTelefono(int idTelefono) {
        this.idTelefono = idTelefono;
    }
    
    
}
