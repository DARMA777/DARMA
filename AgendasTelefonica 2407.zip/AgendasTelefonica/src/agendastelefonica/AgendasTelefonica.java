/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agendastelefonica;

import Util.DataBaseInstance;
import java.sql.Connection;

/**
 *
 * @author cepardov
 */
public class AgendasTelefonica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
