/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Util.DataBaseInstance;
import static Util.DataBaseInstance.closeConnection;
import Vista.Persona;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author cepardov
 */
public class UsuarioImpl {
    protected Connection getConnection(){
        return DataBaseInstance.getInstanceConnection();
    }
    
    //CRUD
    public Object [][] getPersona(){
        int posId = 0;
        
        try {
            //ps position
            PreparedStatement psc = getConnection().prepareStatement("SELECT count(1) as total FROM persona");
            ResultSet res = psc.executeQuery();
            
            res.next();
            posId = res.getInt("total");
            
        } catch (SQLException e){
            System.out.println("Error: "+e);
        }
        
        Object[][] data = new String[posId][9];
        
        try{
            PreparedStatement psc = getConnection().prepareStatement("SELECT idPersona, rutPersona, nombrePersona, paternoPersona, maternoPersona, nacimientoPersona, idUsuario, idTelefono, idCorreo FROM persona ORDER BY idPersona");
            ResultSet res = psc.executeQuery();
            
            int increment = 0;
            
            while(res.next()){
                int idPersona = res.getInt("idPersona");
                String rutPersona = res.getString("rutPersona");
                String nombrePersona = res.getString("nombrePersona");
                String paternoPersona = res.getString("paternoPersona");
                String maternoPersona = res.getString("maternoPersona");
                String nacimientoPersona = res.getString("nacimientoPersona");
                int idUsuario = res.getInt("idUsuario");
                int idTelefono = res.getInt("idTelefono");
                int idCorreo = res.getInt("idCorreo");
                
                data[increment][0] = idPersona;
                data[increment][1] = rutPersona;
                data[increment][2] = nombrePersona;
                data[increment][3] = paternoPersona;
                data[increment][4] = maternoPersona;
                data[increment][5] = nacimientoPersona;
                data[increment][6] = idUsuario;
                data[increment][7] = idTelefono;
                data[increment][8] = idCorreo;
                
                increment++;
            }
            res.close();
            closeConnection();
        } catch (SQLException e){
            System.out.println("Error: "+e);
        }
        
        return data;
    }
    
    public void save(Persona persona){
        PreparedStatement savePersona;
        
        try{
            savePersona = this.getConnection().prepareStatement(
                    "INSERT INTO persona (idPersona, rutPersona, nombrePersona, paternoPersona, maternoPersona, nacimientoPersona, idUsuario, idTelefono, idCorreo) "
                            + "VALUES (?,?,?,?,?,?,?,?,?)");
            savePersona.setInt(1, persona.getIdPersona());
            savePersona.setString(2, persona.getRutPersona());
            savePersona.setString(3, persona.getNombrePersona());
            savePersona.setString(4, persona.getPaternoPersona());
            savePersona.setString(5, persona.getMaternoPersona());
            savePersona.setString(6, persona.getNacimientoPersona());
            savePersona.setInt(7, persona.getIdUsuario());
            savePersona.setInt(8, persona.getIdTelefono());
            savePersona.setInt(9, persona.getIdCorreo());
            
            savePersona.executeQuery();
        } catch (SQLException e){
            System.out.println("Error: "+e);
        }
    }
    
    /**
     * Este metodo actualiza una persona de la base de datos
     * @param persona
     */
    public void update(Persona persona){
        PreparedStatement updatePersona;
        
        try{
            updatePersona = getConnection().prepareStatement("UPDATE persona SET rutPersona=?, nombrePersona=?, paternoPersona=?, maternoPersona=?, nacimientoPersona=?, idUsuario=?, idTelefono=?, idCorreo=? "
                    + "WHERE idPersona=?");
            updatePersona.setString(1, persona.getRutPersona());
            updatePersona.setString(2, persona.getNombrePersona());
            updatePersona.setString(3, persona.getPaternoPersona());
            updatePersona.setString(4, persona.getMaternoPersona());
            updatePersona.setString(5, persona.getNacimientoPersona());
            updatePersona.setInt(6, persona.getIdUsuario());
            updatePersona.setInt(7, persona.getIdTelefono());
            updatePersona.setInt(8, persona.getIdCorreo());
            updatePersona.setInt(9, persona.getIdPersona());
            
            updatePersona.executeQuery();
            
        } catch (SQLException e){
            System.out.println("Error: "+e);
        }
    }
    
    public void delete(Persona persona){
        PreparedStatement delPersona;
        
        try{
            if(Integer.toString(persona.getIdPersona()) != null){
                delPersona = getConnection().prepareStatement("DELETE FROM persona WHERE idPersona = ?");
                
                delPersona.setInt(1, persona.getIdPersona());
                
                delPersona.executeUpdate();
            }
        } catch (SQLException e){
            System.out.println("Error = "+e);
        }
    }
}
